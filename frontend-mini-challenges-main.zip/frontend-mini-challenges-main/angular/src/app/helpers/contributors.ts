export const contributors = new Map([
  [
    'sadanandpai',
    {
      name: 'Sadanand Pai',
      pic: 'https://avatars.githubusercontent.com/u/12962887',
    },
  ],
  [
    'pankajparkar',
    {
      name: 'Pankaj Parkar',
      pic: 'https://avatars.githubusercontent.com/u/5320044',
    },
  ],
]);
