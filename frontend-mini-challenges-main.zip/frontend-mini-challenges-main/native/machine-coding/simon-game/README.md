Description :
The Simon Game is a classic memory game where you must follow a sequence of colors and sounds. The game starts with a single color and sound, and then progressively adds more to the sequence. Your task is to remember and repeat the sequence correctly. The game gets faster and more challenging as you progress.

This project is a digital version of the Simon game that you can play on your computer or mobile device.

Demo :
Play the Simon Game

Features :
Classic Simon game rules and gameplay.
Colorful and engaging user interface.
Progressive difficulty with each level.
Sound and visual feedback for each move.
High scores to track your best performances.
