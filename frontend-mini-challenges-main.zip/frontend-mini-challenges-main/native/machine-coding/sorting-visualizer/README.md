# **Sorting Visualizer**

---

<br>

## **Description 📃**

- This is a Sorting Visualizer which uses Bubble Sort Algoritm made using HTML, CSS and JS

## **Functionalities 🎮**

- Shows which two numbers it is comparing with green color and shows swapping with red color
- Provides a easy way to visualize the bubble sort function <br>

## **How to play? 🕹️**

- Generate Array by clicking the genreate button.
- Sort Array by clicking the Sort button.

<br>
