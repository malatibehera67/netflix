export interface Contributor {
  username: string;
  avatar: string;
}

export const contributorsList = [
  { username: 'sadanandpai', avatar: '12962887' },
  { username: 'arpansaha13', avatar: '82361490' },
];
