import styles from './footer.module.scss';

function Footer() {
  return <footer className={styles.footer}>Copyright © 2023</footer>;
}

export default Footer;
