export const testimonials = [
  {
    id: 1,
    name: 'Dummy User 1',
    role: 'Frontend Engineer',
    img: 'https://avatars.githubusercontent.com/u/1111111',
    comment:
      'Great resource for learning and frontend interview preparation. It helped me to crack browser coding rounds of multiple companies',
  },
];
