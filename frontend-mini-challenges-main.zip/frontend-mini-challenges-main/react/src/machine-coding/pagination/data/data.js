export const FOODS = [
    {
        id: 1,
        name: 'Pizza',
        price: 10,
    },
    {
        id: 2,
        name: 'Burger',
        price: 20,
    },
    {
        id: 3,
        name: 'Fries',
        price: 30,
    },
    {
        id: 4,
        name: 'Pasta',
        price: 15,
    },
    {
        id: 5,
        name: 'Salad',
        price: 30,
    },
    {
        id: 6,
        name: 'Soup',
        price: 20,
    },
    {
        id: 7,
        name: 'Marshmallows',
        price: 10,
    },
    {
        id: 8,
        name: 'Ice cream',
        price: 20,
    },
    {
        id: 9,
        name: 'Cake',
        price: 30,
    },
    {
        id: 10,
        name: 'Donut',
        price: 5,
    },
    {
        id: 11,
        name: 'Sushi',
        price: 25,
    },
    {
        id: 12,
        name: 'Taco',
        price: 12,
    },
    {
        id: 13,
        name: 'Steak',
        price: 35,
    },
    {
        id: 14,
        name: 'Chicken Wings',
        price: 18,
    },
    {
        id: 15,
        name: 'Lasagna',
        price: 22,
    },
    {
        id: 16,
        name: 'Burrito',
        price: 15,
    },
    {
        id: 17,
        name: 'Sushi Roll',
        price: 27,
    },
    {
        id: 18,
        name: 'Grilled Cheese Sandwich',
        price: 10,
    },
    {
        id: 19,
        name: 'Hot Dog',
        price: 8,
    },
    {
        id: 20,
        name: 'Nachos',
        price: 12,
    },
    {
        id: 21,
        name: 'Ramen',
        price: 14,
    },
    {
        id: 22,
        name: 'Pho',
        price: 16,
    },
    {
        id: 23,
        name: 'Gyros',
        price: 18,
    },
    {
        id: 24,
        name: 'Ceviche',
        price: 20,
    },
    {
        id: 25,
        name: 'Miso Soup',
        price: 8,
    },
    {
        id: 26,
        name: 'Crispy Tofu',
        price: 12,
    },
    {
        id: 27,
        name: 'Paella',
        price: 28,
    },
    {
        id: 28,
        name: 'Fish and Chips',
        price: 17,
    },
    {
        id: 29,
        name: 'Shrimp Scampi',
        price: 24,
    },
    {
        id: 30,
        name: 'Cannoli',
        price: 10,
    },
    {
        id: 31,
        name: 'Churros',
        price: 7,
    },
    {
        id: 32,
        name: 'Baklava',
        price: 9,
    },
    {
        id: 33,
        name: 'Tiramisu',
        price: 12,
    },
    {
        id: 34,
        name: 'Cheesecake',
        price: 18,
    },
    {
        id: 35,
        name: 'Chocolate Fondue',
        price: 20,
    },
];
