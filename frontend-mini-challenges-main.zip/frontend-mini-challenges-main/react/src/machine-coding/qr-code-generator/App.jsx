import QRCodeGenerator from './QRCodeGenerator';
import React from 'react';

function App() {
  return (
    <div className="App">
      <QRCodeGenerator />
    </div>
  );
}

export default App;
