export type ResultObj = {
  score: number;
  correctAnswers: number;
  wrongAnswers: number;
}
