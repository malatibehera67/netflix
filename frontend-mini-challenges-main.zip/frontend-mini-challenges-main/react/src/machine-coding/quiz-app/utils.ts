export const addLeadingZero = (number: number) => (number > 9 ? number : `0${number}`);
