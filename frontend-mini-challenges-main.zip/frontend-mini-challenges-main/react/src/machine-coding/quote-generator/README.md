# **Quote Generator**

---

<br>

## **Description 📃**

- This is a Quote Generator which uses quotable API to fetch quotes

## **Functionalities 🎮**

- Displays a Random Quote every time the user presses the generate button
- User can add tags to generate quotes related to the tags

<br>

## **How to play? 🕹️**

- Generate Quotes by clicking the Generate button.

<br>
